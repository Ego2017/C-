#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/io.h>

#include <sitest.h>
#include <libsio.h>

int main(void)
{
	return 0;
}
