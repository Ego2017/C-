# FRU tool

## creat_bin_file

./ipmi-fru-it/ipmi-fru-it -s 2048 -c ./ipmi-fru-it/fru_multi-record.conf -o FRU.bin -a

## display_info

```
./ipmi-fru-parser_optimize/bin/parser -f ./FRU.bin -o ./ipmi-fru-parser_optimize/example/fru.conf
```

## Use Instraction

1. chassis,board and product is optional
2. the number of muti_record is 0 to 6

## commend explain

```
./ipmi-fru-it/ipmi-fru-it -s 2048 -c [address of fru_multi-record.conf] -o [address of FRU.bin] -a

./ipmi-fru-parser_optimize/bin/parser -f [address of FRU.bin] -o [address of fru.conf which is created by this code]

```

if you want to create bin file and parser bin file, you can use this command
```
sh run_fru.sh

```
## Optimize Code

1. fix a bug which have difficult to identify the last module of muti_record
2. add warning message of muti_record type and version
