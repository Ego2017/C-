#!/bin/bash
./ipmi-fru-it/ipmi-fru-it -s 2048 -c ./ipmi-fru-it/fru_multi-record.conf -o FRU.bin -a
./ipmi-fru-parser_optimize/bin/parser -f ./FRU.bin -o ./ipmi-fru-parser_optimize/example/fru.conf
